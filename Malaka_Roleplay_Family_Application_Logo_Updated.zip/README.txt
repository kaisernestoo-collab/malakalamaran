MALAKA ROLEPLAY — FAMILY & GANGSTER APPLICATION

Cara menjalankan:
1. Extract ZIP ini.
2. Buka index.html di browser, atau upload semua file ke hosting website.
3. Logo kota sudah ditautkan dari URL yang diberikan, jadi perangkat yang membuka website perlu terhubung ke internet agar logo tampil.
4. Formulir mengarahkan ke WhatsApp Founder (+6281400766700) dengan isi lamaran yang sudah terisi.

Catatan:
Website statis ini tidak dapat mengirim pesan WhatsApp secara diam-diam/otomatis tanpa tindakan pengguna. Setelah tombol submit ditekan, WhatsApp terbuka dan pengguna perlu menekan tombol Kirim. Untuk pengiriman otomatis tanpa langkah tersebut, diperlukan WhatsApp Business Platform/API dan backend yang dikonfigurasi.
